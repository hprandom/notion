import { Page404 } from 'components'

export default Page404
